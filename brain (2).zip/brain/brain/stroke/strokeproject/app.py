import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from imblearn.combine import SMOTEENN

def balance_and_classify(file, impacts, outcome, inps):
    # Read the CSV file
    data = pd.read_csv(file)

    # Separate the features and the target variable
    X = data[impacts]
    Y = data[outcome]
    Y = Y.round()

    # Check class imbalance
    class_counts = Y.value_counts()
    print("Class Distribution:")
    print(class_counts)

    # If there is a class imbalance, balance the dataset using SMOTE
    if class_counts[0] < class_counts[1]:
        smote = SMOTE(sampling_strategy='auto')
        X_resampled, Y_resampled = smote.fit_resample(X, Y)
    else:
        X_resampled, Y_resampled = X, Y

    # Train the SVC classifier on the balanced dataset
    clf = SVC(kernel='linear')
    clf.fit(X_resampled, Y_resampled)

    # Make predictions for the input
    nx = [inps]
    pred = clf.predict(nx)

    # Print the class distribution in the balanced dataset
    balanced_class_counts = pd.Series(Y_resampled).value_counts()
    print("Balanced Class Distribution:")
    print(balanced_class_counts)

    return pred[0]

pred = balance_and_classify("balanced_data_1.csv", 
                            ['gender', 'age', 'hypertension', 'heart_disease', 'ever_married', 'work_type', 
                             'Residence_type', 'avg_glucose_level', 'bmi', 'smoking_status'], 
                            "stroke", 
                            [1,85,1,1,1,1,1,300,36.6,1])

print("Predicted Class:", pred)