from django.db import models

# Create your models here.

# Define the Patient model
#class Patient(models.Model):
    # Define your fields here
#   name = models.CharField(max_length=100)
#   email = models.EmailField()